O arquivo com extensão drawio é o arquivo utilizado na ferramenta
online para criação de diagramas https://app.diagrams.net/.