import "./Home.css";

function Home() {
  return (
    <div className="App">
      <header className="App-header">
        <p>Novo PI 2 em React!</p>
      </header>
    </div>
  );
}

export default Home;
